##############################################################
# modules/iam/main.tf
#
# Two roles following least-privilege:
#
#  ecs_execution_role  — used by the ECS agent to pull images
#                        from ECR and write logs to CloudWatch.
#
#  ecs_task_role       — assumed by your application code at
#                        runtime (add only the permissions your
#                        app actually needs here).
##############################################################

locals {
  name_prefix = "${var.project_name}-${var.environment}"
}

# ─── ECS Task Execution Role ────────────────────────────────

data "aws_iam_policy_document" "ecs_assume_role" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "ecs_execution" {
  name               = "${local.name_prefix}-ecs-execution-role"
  assume_role_policy = data.aws_iam_policy_document.ecs_assume_role.json
  tags               = { Name = "${local.name_prefix}-ecs-execution-role" }
}

# AWS managed policy: pull ECR images + write CloudWatch Logs
resource "aws_iam_role_policy_attachment" "ecs_execution_managed" {
  role       = aws_iam_role.ecs_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

# Additional inline policy: read Secrets Manager secrets by path
resource "aws_iam_role_policy" "ecs_execution_secrets" {
  name = "${local.name_prefix}-ecs-secrets-policy"
  role = aws_iam_role.ecs_execution.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ReadAppSecrets"
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue",
          "ssm:GetParameters",
          "ssm:GetParameter"
        ]
        Resource = [
          "arn:aws:secretsmanager:${var.aws_region}:${var.aws_account_id}:secret:${local.name_prefix}/*",
          "arn:aws:ssm:${var.aws_region}:${var.aws_account_id}:parameter/${local.name_prefix}/*"
        ]
      }
    ]
  })
}

# ─── ECS Task Role ──────────────────────────────────────────
# Your application code runs as this role. Add only what the
# app actually calls (e.g. S3, DynamoDB, SQS).

resource "aws_iam_role" "ecs_task" {
  name               = "${local.name_prefix}-ecs-task-role"
  assume_role_policy = data.aws_iam_policy_document.ecs_assume_role.json
  tags               = { Name = "${local.name_prefix}-ecs-task-role" }
}

resource "aws_iam_role_policy" "ecs_task_app" {
  name = "${local.name_prefix}-ecs-task-app-policy"
  role = aws_iam_role.ecs_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      # Example: allow reading from a specific S3 bucket
      # Uncomment and adjust as your app requires.
      # {
      #   Sid    = "S3ReadAssets"
      #   Effect = "Allow"
      #   Action = ["s3:GetObject", "s3:ListBucket"]
      #   Resource = [
      #     "arn:aws:s3:::${local.name_prefix}-assets",
      #     "arn:aws:s3:::${local.name_prefix}-assets/*"
      #   ]
      # },
      {
        Sid    = "CloudWatchMetrics"
        Effect = "Allow"
        Action = [
          "cloudwatch:PutMetricData",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "*"
      }
    ]
  })
}

##############################################################
# variables.tf + outputs.tf
##############################################################

variable "project_name"   { type = string }
variable "environment"    { type = string }
variable "aws_region"     { type = string }
variable "aws_account_id" { type = string }
variable "ecr_repo_arn"   { type = string }

output "ecs_execution_role_arn" { value = aws_iam_role.ecs_execution.arn }
output "ecs_task_role_arn"      { value = aws_iam_role.ecs_task.arn }
