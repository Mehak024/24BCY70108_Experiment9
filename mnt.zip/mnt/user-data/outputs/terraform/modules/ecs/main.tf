##############################################################
# modules/ecs/main.tf
#
# ECS Cluster (Fargate)
# Task Definition (with container definition + log group)
# ECS Service (rolling deploy, ALB integration)
# Auto Scaling (CPU-based target tracking)
##############################################################

locals {
  name_prefix = "${var.project_name}-${var.environment}"
}

# ─── CloudWatch Log Group ────────────────────────────────────

resource "aws_cloudwatch_log_group" "app" {
  name              = "/ecs/${local.name_prefix}"
  retention_in_days = 30
  tags              = { Name = "${local.name_prefix}-logs" }
}

# ─── ECS Cluster ────────────────────────────────────────────

resource "aws_ecs_cluster" "main" {
  name = "${local.name_prefix}-cluster"

  setting {
    name  = "containerInsights"
    value = "enabled"
  }

  tags = { Name = "${local.name_prefix}-cluster" }
}

resource "aws_ecs_cluster_capacity_providers" "main" {
  cluster_name       = aws_ecs_cluster.main.name
  capacity_providers = ["FARGATE", "FARGATE_SPOT"]

  default_capacity_provider_strategy {
    capacity_provider = "FARGATE"
    weight            = 1
    base              = 1
  }
}

# ─── Task Definition ────────────────────────────────────────

resource "aws_ecs_task_definition" "app" {
  family                   = "${local.name_prefix}-task"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.container_cpu
  memory                   = var.container_memory
  execution_role_arn       = var.execution_role_arn
  task_role_arn            = var.task_role_arn

  container_definitions = jsonencode([
    {
      name      = "${local.name_prefix}-app"
      image     = "${var.ecr_repository_url}:${var.image_tag}"
      essential = true

      portMappings = [
        {
          containerPort = var.container_port
          protocol      = "tcp"
        }
      ]

      # Environment variables (non-secret)
      environment = [
        for k, v in var.environment_variables : { name = k, value = v }
      ]

      # Secrets from AWS Secrets Manager — add as needed:
      # secrets = [
      #   {
      #     name      = "DATABASE_URL"
      #     valueFrom = "arn:aws:secretsmanager:REGION:ACCOUNT:secret:myapp-prod/db-url"
      #   }
      # ]

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.app.name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "app"
        }
      }

      healthCheck = {
        command     = ["CMD-SHELL", "curl -f http://localhost:${var.container_port}/health || exit 1"]
        interval    = 30
        timeout     = 5
        retries     = 3
        startPeriod = 60
      }

      # Graceful shutdown: gives in-flight requests time to drain
      stopTimeout = 30
    }
  ])

  tags = { Name = "${local.name_prefix}-task" }

  lifecycle {
    create_before_destroy = true
  }
}

# ─── ECS Service ────────────────────────────────────────────

resource "aws_ecs_service" "app" {
  name            = "${local.name_prefix}-service"
  cluster         = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.app.arn
  desired_count   = var.desired_count
  launch_type     = "FARGATE"

  # Rolling deployment — zero downtime
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200

  deployment_circuit_breaker {
    enable   = true
    rollback = true # Auto-rollback on repeated task failures
  }

  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [var.ecs_sg_id]
    assign_public_ip = false # Tasks live in private subnets
  }

  load_balancer {
    target_group_arn = var.target_group_arn
    container_name   = "${local.name_prefix}-app"
    container_port   = var.container_port
  }

  # Ignore task definition changes made outside Terraform (e.g. by CI/CD)
  lifecycle {
    ignore_changes = [task_definition, desired_count]
  }

  tags = { Name = "${local.name_prefix}-service" }
}

# ─── Auto Scaling ────────────────────────────────────────────

resource "aws_appautoscaling_target" "ecs" {
  max_capacity       = var.max_capacity
  min_capacity       = var.min_capacity
  resource_id        = "service/${aws_ecs_cluster.main.name}/${aws_ecs_service.app.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

# Scale out: add tasks when CPU > threshold for 2 consecutive periods
resource "aws_appautoscaling_policy" "cpu_scale_out" {
  name               = "${local.name_prefix}-cpu-scale-out"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.ecs.resource_id
  scalable_dimension = aws_appautoscaling_target.ecs.scalable_dimension
  service_namespace  = aws_appautoscaling_target.ecs.service_namespace

  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }

    target_value       = var.cpu_scale_out_threshold
    scale_in_cooldown  = 300 # 5 min — prevent thrashing
    scale_out_cooldown = 60  # 1 min — respond quickly to load spikes
  }
}

# Memory-based scaling (useful for memory-bound workloads)
resource "aws_appautoscaling_policy" "memory_scale_out" {
  name               = "${local.name_prefix}-memory-scale-out"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.ecs.resource_id
  scalable_dimension = aws_appautoscaling_target.ecs.scalable_dimension
  service_namespace  = aws_appautoscaling_target.ecs.service_namespace

  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageMemoryUtilization"
    }

    target_value       = 80
    scale_in_cooldown  = 300
    scale_out_cooldown = 60
  }
}

# ─── CloudWatch Alarms ───────────────────────────────────────

resource "aws_cloudwatch_metric_alarm" "high_cpu" {
  alarm_name          = "${local.name_prefix}-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "CPUUtilization"
  namespace           = "AWS/ECS"
  period              = 60
  statistic           = "Average"
  threshold           = var.cpu_scale_out_threshold
  alarm_description   = "ECS service CPU above ${var.cpu_scale_out_threshold}%"
  treat_missing_data  = "notBreaching"

  dimensions = {
    ClusterName = aws_ecs_cluster.main.name
    ServiceName = aws_ecs_service.app.name
  }
}

resource "aws_cloudwatch_metric_alarm" "low_cpu" {
  alarm_name          = "${local.name_prefix}-low-cpu"
  comparison_operator = "LessThanThreshold"
  evaluation_periods  = 3
  metric_name         = "CPUUtilization"
  namespace           = "AWS/ECS"
  period              = 60
  statistic           = "Average"
  threshold           = var.cpu_scale_in_threshold
  alarm_description   = "ECS service CPU below ${var.cpu_scale_in_threshold}%"
  treat_missing_data  = "notBreaching"

  dimensions = {
    ClusterName = aws_ecs_cluster.main.name
    ServiceName = aws_ecs_service.app.name
  }
}

##############################################################
# variables.tf
##############################################################

variable "project_name"             { type = string }
variable "environment"              { type = string }
variable "aws_region"               { type = string }
variable "vpc_id"                   { type = string }
variable "private_subnet_ids"       { type = list(string) }
variable "ecs_sg_id"                { type = string }
variable "target_group_arn"         { type = string }
variable "ecr_repository_url"       { type = string }
variable "image_tag"                { type = string }
variable "container_port"           { type = number }
variable "container_cpu"            { type = number }
variable "container_memory"         { type = number }
variable "desired_count"            { type = number }
variable "min_capacity"             { type = number }
variable "max_capacity"             { type = number }
variable "cpu_scale_out_threshold"  { type = number }
variable "cpu_scale_in_threshold"   { type = number }
variable "execution_role_arn"       { type = string }
variable "task_role_arn"            { type = string }
variable "environment_variables"    { type = map(string) }

##############################################################
# outputs.tf
##############################################################

output "cluster_name"  { value = aws_ecs_cluster.main.name }
output "service_name"  { value = aws_ecs_service.app.name }
output "log_group"     { value = aws_cloudwatch_log_group.app.name }
