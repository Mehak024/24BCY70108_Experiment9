##############################################################
# modules/ecr/main.tf
# Private ECR repository with image scanning and lifecycle
# policy to keep image storage costs in check.
##############################################################

locals {
  name_prefix = "${var.project_name}-${var.environment}"
}

resource "aws_ecr_repository" "app" {
  name                 = "${local.name_prefix}-app"
  image_tag_mutability = "MUTABLE" # IMMUTABLE recommended for strict production

  image_scanning_configuration {
    scan_on_push = true # Automatic CVE scanning on every push
  }

  encryption_configuration {
    encryption_type = "AES256"
  }

  tags = { Name = "${local.name_prefix}-ecr" }
}

# Keep only the 10 most recent images to reduce storage costs
resource "aws_ecr_lifecycle_policy" "app" {
  repository = aws_ecr_repository.app.name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Retain last 10 images"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = 10
        }
        action = { type = "expire" }
      }
    ]
  })
}

##############################################################
# variables.tf + outputs.tf
##############################################################

variable "project_name" { type = string }
variable "environment"  { type = string }

output "repository_url" { value = aws_ecr_repository.app.repository_url }
output "repository_arn" { value = aws_ecr_repository.app.arn }
output "repository_name" { value = aws_ecr_repository.app.name }
